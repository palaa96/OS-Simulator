$(document).ready(function(){
    $('#page-heading').delay(1000).slideDown('slow');
    $('#middle-content').delay(1000).slideDown('slow');
});