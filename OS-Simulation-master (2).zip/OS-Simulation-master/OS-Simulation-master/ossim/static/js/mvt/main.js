$(document).ready(function () {
    $('#page-heading').delay(1000).slideDown('slow');
    $('#input-data-form').delay(1000).fadeIn('slow');
});