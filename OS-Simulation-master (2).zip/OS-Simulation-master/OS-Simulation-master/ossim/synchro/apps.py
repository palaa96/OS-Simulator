from django.apps import AppConfig


class SynchroConfig(AppConfig):
    name = 'synchro'
