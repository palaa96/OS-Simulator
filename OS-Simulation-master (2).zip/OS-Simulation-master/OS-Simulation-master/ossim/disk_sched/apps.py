from django.apps import AppConfig


class DiskSchedConfig(AppConfig):
    name = 'disk_sched'
