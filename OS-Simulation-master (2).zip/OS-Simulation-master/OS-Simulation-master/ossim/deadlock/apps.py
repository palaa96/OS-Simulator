from django.apps import AppConfig


class DeadlockConfig(AppConfig):
    name = 'deadlock'
