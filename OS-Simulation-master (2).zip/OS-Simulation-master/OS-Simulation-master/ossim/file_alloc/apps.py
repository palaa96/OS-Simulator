from django.apps import AppConfig


class FileAllocConfig(AppConfig):
    name = 'file_alloc'
