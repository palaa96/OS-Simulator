from django.apps import AppConfig


class SocketsConfig(AppConfig):
    name = 'sockets'
