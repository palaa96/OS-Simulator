from django.apps import AppConfig


class BootingConfig(AppConfig):
    name = 'booting'
