# GUI

Install flask
```
$ pip install flask
```

Run
```
$ python app.py
```

Open the link

Add all your templates within the templates folder else flask wont recognise it

