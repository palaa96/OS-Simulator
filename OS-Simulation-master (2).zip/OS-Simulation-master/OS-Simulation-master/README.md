# OS-Simulation
A repository to build a software that can simulate the features of an operating system
